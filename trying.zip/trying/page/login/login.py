from huskypo import By, Element, Elements
from trying.huskypo_extension.page import Page


class LoginPage(Page):
    # page
    page = '登入頁面'

    language = Element(By.IOS_PREDICATE, 'name IN {"ZH", "EN"}', remark='語言')
    language_image = Element(By.ACCESSIBILITY_ID, 'img_cube_language_Select')
    language_zh = Element(By.ACCESSIBILITY_ID, '中文')
    language_en = Element(By.ACCESSIBILITY_ID, 'English')
    language_save_button = Element(
        By.IOS_CLASS_CHAIN,
        '**/XCUIElementTypeButton[`name IN {"儲存", "Save"}`]',
        remark='儲存(Save)按鈕')

    # scrollview
    scrollview = Element(By.IOS_PREDICATE, 'type == "XCUIElementTypeScrollView"', remark=f'{page}_scrollview')

    # uat version
    uat_version = Element(By.IOS_PREDICATE, 'label BEGINSWITH "UAT"', remark=f'{page}_UAT版本資訊')

    # 登入到首頁彈窗，現在先用image第二張來判斷
    bell_popup = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeImage[2]', remark=f'{page}_彈窗小鈴鐺')

    type_image = Element(By.IOS_PREDICATE, 'type=="XCUIElementTypeImage"')

    remember_radio = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label==" 記住我"`]', remark="記住我單選框")

    menu = Element(By.ACCESSIBILITY_ID, 'ic cube navbar more gray', remark="菜單按鈕")

    fin = Element(By.ACCESSIBILITY_ID, '金融商品', remark='登入前_金融商品區塊')
    fin_exr = Element(By.ACCESSIBILITY_ID, '利匯率', remark='登入前_利匯率選項')
    fin_exr_twd = Element(By.ACCESSIBILITY_ID, '臺幣存放款利率', remark='登入前_利匯率_臺幣存放款利率')
    fin_exr_frd = Element(By.ACCESSIBILITY_ID, '外幣存款利率', remark="登入前_利匯率_外幣存款利率")
    fin_exr_fxr = Element(By.ACCESSIBILITY_ID, '外幣匯率', remark="登入前_利匯率_外幣匯率")
    fin_exr_est = Element(By.ACCESSIBILITY_ID, '換匯試算', remark="登入前_利匯率_換匯試算")

    others_go_to_web_cube = Element(By.ACCESSIBILITY_ID, '前往網銀')

    others = Element(By.ACCESSIBILITY_ID, '其他')

    input_field = Elements(By.CLASS_NAME, 'XCUIElementTypeSecureTextField')

    

    userid_text = Element(By.ACCESSIBILITY_ID, '身分證字號', remark="身分證字號文本")
    userid_input = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeSecureTextField[1]', remark="身分證字號輸入框")
    username_text = Element(By.ACCESSIBILITY_ID, '用戶代號', remark="用戶代號文本")
    username_input = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeSecureTextField[2]', remark="用戶代號輸入框")
    userpsw_text = Element(By.ACCESSIBILITY_ID, '網銀密碼', remark="網銀密碼文本")
    userpsw_input = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeSecureTextField[3]', remark="網銀密碼輸入框")
    userid_input_eye = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "ic cube eye close"`][1]',
                               remark="身分證字號顯示按鈕")
    username_input_eye = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "ic cube eye close"`][1]',
                                 remark="用戶代號顯示按鈕")
    userpsw_input_eye = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "ic cube eye close"`][1]',
                                remark="網銀密碼顯示按鈕")
    userid_input_show = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeTextField[1]',
                                remark="身分證字號輸入框_顯示狀態")
    username_input_show = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeTextField[2]',
                                  remark="用戶代號輸入框_顯示狀態")
    userpsw_input_show = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeTextField[3]',
                                 remark="網銀密碼輸入框_顯示狀態")

    login_button = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "登入"`]')

    forget_psw = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label CONTAINS "忘記"`]',
                         remark='忘記代號密碼按鈕')
    signup = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label CONTAINS "註冊、開戶或開卡"`]',
                     remark="註冊、開戶或開卡按鈕")
    signup_button = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label CONTAINS "開立帳戶"`]', remark='開立帳戶按鈕')

    # 切換語言
    language_switch_button = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label == "ZH"`]', remark='語言切換按鈕')
    language_image = Element(By.ACCESSIBILITY_ID, 'img_cube_language_Select')
    language_switch_zh = Element(By.ACCESSIBILITY_ID, '中文')
    language_zh_checkbox = Element(
        By.XPATH,
        '//XCUIElementTypeStaticText[@name="中文"]/parent::XCUIElementTypeCell/XCUIElementTypeImage',
        remark='中文確認')
    saved_language_button = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label == "儲存"`]')

    # 手勢登入
    gesture_icon = Element(By.ACCESSIBILITY_ID, 'gesture', remark="手勢登入icon")
    gesture_text = Element(By.ACCESSIBILITY_ID, '手勢登入', remark="手勢登入text")

    # mock介面element
    single_api_path_text = Element(By.ACCESSIBILITY_ID, '單一 API Path', remark="「單一 API Path」文字")
    mock_api_text_field = Element(By.CLASS_NAME, 'XCUIElementTypeTextField', remark="單一api Text Field")

    error_mode_text = Element(By.ACCESSIBILITY_ID, 'Error Mode', remark="「Error Mode」文字")
    error_mode_field = Element(
        By.XPATH,
        '//XCUIElementTypeStaticText[@name="Error Mode"]/following-sibling::*[@type="XCUIElementTypeStaticText"]',
        remark="單一api Text Field")

    error_mode_http_error = Element(By.ACCESSIBILITY_ID, 'httperror', remark="httpError error mode")
    error_mode_timeout = Element(By.ACCESSIBILITY_ID, 'timeout', remark="timeout error mode")
    error_mode_response_empty = Element(By.ACCESSIBILITY_ID, 'responseempty', remark="responseEmpty error mode")
    error_mode_response_error = Element(By.ACCESSIBILITY_ID, 'responseformaterror', remark="responseError error mode")
    error_mode_status_code_9999 = Element(By.ACCESSIBILITY_ID, 'status_code_9999', remark="status_code_9999 error mode")

    reset_btn = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "重置"`]', remark="「重置」按鈕")
    apply_btn = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "套用"`]', remark="「套用」按鈕")

    # 開戶相關
    open_account_button = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name CONTAINS "開立帳戶"`]')


class GestureLoginPage(Page):
    content = Element(By.IOS_PREDICATE, 'label CONTAINS "點圖形密碼"', remark='手勢登入頁面_說明')

    account_login = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label == "帳號密碼登入"`]',
                            remark="帳號密碼登入按鈕")

    dots_filter = 'position() mod 2 = 0'
    dots = Elements(
        By.XPATH,
        f'//XCUIElementTypeStaticText[contains(@name, "請畫出")]/following::XCUIElementTypeImage[{dots_filter}]')

    # 本人驗證彈窗
    verify_popup_confirm = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`label == "立即驗證"`]',
                                   remark="立即驗證按鈕")


class SignUpOrEnableAppOrActiveCard(Page):
    title = Element(By.IOS_PREDICATE, 'label CONTAINS "加入我們"', remark='加入我們標題')
    signup = Element(By.ACCESSIBILITY_ID, '我要開立帳戶')
    enable_App = Element(By.ACCESSIBILITY_ID, '我要啟用網銀App')
    active_card = Element(By.ACCESSIBILITY_ID, '我要開卡')

    personal_data_usage_notification_statement = Element(
        By.IOS_PREDICATE, 'name CONTAINS "個人資料運用告知聲明"', remark='個人資料運用告知聲明導向按鈕')
