from huskypo import By, Element
from trying.huskypo_extension.page import Page


class LoginPopup(Page):

    # general
    # contains未正常登出 讓目前的裝置記住我 開啟生物辨識快速登入功能 變更密碼 登入兩步驟驗證
    pred_abnormal = 'name CONTAINS "未正常登出"'
    pred_remember = 'name CONTAINS "裝置記住我"'
    pred_fido = 'name == "開啟生物辨識快速登入功能"'
    pred_tfa = 'name BEGINSWITH "兩步驟驗證"'
    pred_password = 'name CONTAINS "變更密碼"'

    common_text = Element(
        By.IOS_PREDICATE,
        f'{pred_abnormal} OR {pred_remember} OR {pred_fido} OR {pred_tfa} OR {pred_password}',
        remark='共同判斷彈窗文本')

    common_mock_text = Element(
        By.IOS_PREDICATE,
        f'{pred_abnormal} OR {pred_remember} OR {pred_fido}',
        remark='mock共同判斷彈窗文本')

    # 讓目前的裝置記住我
    remember_title = Element(By.ACCESSIBILITY_ID, '讓目前的裝置記住我')
    remember_content = Element(By.ACCESSIBILITY_ID, '您將可以使用完整推播功能。其他使用者的登入資訊則會被清除。')
    remember_dismiss = Element(
        By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "現在不要"`]', remark='讓目前的裝置記住我_現在不要按鈕')
    remember_accept = Element(
        By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "記住我"`]', remark='讓目前的裝置記住我_記住我按鈕')

    # 未正常登出彈窗
    abnormal_content = Element(By.IOS_PREDICATE, f'{pred_abnormal}', remark='未正常登出_內文')
    abnormal_dismiss = Element(
        By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name CONTAINS "取消本次登入"`]', remark='未正常登出_取消本次登入按鈕')
    abnormal_accept = Element(
        By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name CONTAINS "繼續本次登入"`]', remark='未正常登出_繼續本次登入按鈕')

    # 開啟生物辨識快速登入功能彈窗
    fido_title = Element(By.IOS_PREDICATE, f'{pred_fido}', remark='開啟生物辨識快速登入功能_標題')
    fido_content = Element(By.IOS_PREDICATE, 'name CONTAINS "FIDO"', remark='開啟生物辨識快速登入功能_內文')
    fido_dismiss = Element(
        By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "取消"`]', remark='開啟生物辨識快速登入功能_取消按鈕')
    fido_accept = Element(
        By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "馬上開始"`]', remark='開啟生物辨識快速登入功能_馬上開始按鈕')

    # 2fa
    tfa_title = Element(By.IOS_PREDICATE, 'name CONTAINS "兩步驟驗證"')
    tfa_confirm = Element(By.IOS_CLASS_CHAIN, '**/XCUIElementTypeButton[`name == "立即啟用"`]')

    # TODO 變更密碼彈窗內容


class UpgradeSecurityPopup(Page):

    # 此為手勢登入 勿刪

    pp = '登入安全再升級'

    title_ = Element(By.IOS_PREDICATE, 'name BEGINSWITH "登入安全再升級"', remark=f'{pp}_登入安全再升級')

    dismiss = Element(By.IOS_PREDICATE, 'label == "暫時不用"', remark=f'{pp}_暫時不用按鈕')
