import os
import sys
repo_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(repo_path)

import pytest

from huskypo import logconfig

from trying import allure_generator

if __name__ == '__main__':

    logconfig.basic()
    pytest.main()
    allure_generator.output_allure_html()
