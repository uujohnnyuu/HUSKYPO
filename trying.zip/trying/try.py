a = (1,2,3,4,5)

down = a[1:-1]
send = a[-1]
up = a[-2::-1]

print(down)
print(send)
print(up)