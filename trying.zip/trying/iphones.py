class Device1:
    deviceName = '800599'
    udid = "00008120-000C7D5101DB401E"

class Device2:
    deviceName = '800713'
    udid = "00008120-00196516349B401E"