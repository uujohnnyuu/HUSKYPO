import pytest
from selenium import webdriver as web_webdriver
from appium import webdriver as app_webdriver
from appium.options.common import AppiumOptions

from huskypo import Log, Appium, logstack

from trying import iphones
from trying import apps
from trying.module.common import Common

@pytest.fixture(scope='function')
def driver():

    # Chrome 自動化設定
    options=web_webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-automation','enable-logging']) #不啟用自動化提示訊息
    prefs={
        "profile.default_content_setting_values":{'notifications':2},  # 不啟用開啟通知彈窗
        "credentials_enable_service": False,  # 不保存用户的登錄資訊
        "profile.password_manager_enabled": False,  # 不啟用儲存密碼彈窗
        "profile.default_content_settings.popups": 0,  # 下載檔案時不會出現下載視窗
    }
    options.add_experimental_option('prefs', prefs)

    # 設定 chrome driver
    # current_file_path = os.path.abspath(__file__)
    # root_path = os.path.dirname(os.path.dirname(current_file_path))
    # chrome_driver_path = os.path.join(root_path, 'webdriver', 'chromedriver')
    # selenium 4.0 已無需自行安裝並設定driver路徑，但內網還是需要
    chromedriver = web_webdriver.Chrome(options=options)

    # 隱性等待，判斷指定元素狀態為 existing 才會停止等待，此例最多等待到10秒
    chromedriver.implicitly_wait(10)
    
    # return chrome driver 給 testcase 使用
    # 一旦 return 給 testcase 後，在測試結束前會暫停執行
    # 直到測試結束後，才會執行 yield 之後的程序
    yield chromedriver
    
    # 結束測試並關閉driver
    chromedriver.quit()


@pytest.fixture(scope='function')
def iphone():
    Log.RECORD = True
    device = iphones.Device1
    options = AppiumOptions()
    options.set_capability('platformName', 'iOS')
    options.set_capability('automationName', 'XCUITest')
    if iphone is not None:
        options.set_capability('deviceName', device.deviceName)
        options.set_capability('udid', device.udid)
    options.set_capability('bundleId', apps.APP1)
    options.set_capability('noReset', False)
    options.set_capability('forceAppLaunch', True)
    options.set_capability('autoGrantPermissions', True)
    options.set_capability('includeSafariInWebviews', True)

    connection = Appium.LOCALHOST + ':4801'
    driver = app_webdriver.Remote(connection, options=options)
    logstack.info(f'🟡 driver session_id: {driver.session_id}')
    yield driver
    driver.quit()


@pytest.fixture(scope='function')
def common(iphone):
    return Common(iphone)

@pytest.fixture(scope='function')
def prelogin(common: Common):
    common.prelogin_process()