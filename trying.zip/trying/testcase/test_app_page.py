import time

import pytest
from appium.webdriver.webdriver import WebDriver

from huskypo import logstack
from huskypo.config import Log
from huskypo import SA
from huskypo.types import WebElementTuple

from trying.module.common import Common

from trying.page.ios.panel import Keyboard 
from trying.page.login.login import LoginPage
from trying.page.common.bottom import Bottom
from trying.page.home.home import HomePage
from trying.page.more.more import MorePage


class TestAppPage:

    @pytest.mark.app
    def test01(self, iphone, prelogin, common: Common):
        
        keyboard = Keyboard(iphone)
        login_page = LoginPage(iphone)
        bottom = Bottom(iphone)
        home_page = HomePage(iphone)
        more_page = MorePage(iphone)

        user = ['X134624817', 'xxxx1234', '1111']

        login_page.login_button.click()

        login_page.userid_input.send_keys(user[0])
        login_page.username_input.send_keys(user[1])
        login_page.userpsw_input.send_keys(user[2])
        keyboard.done.click()

        # 應要被隱藏
        assert login_page.input_field.get_attributes('value') == [None, None, None]

        login_page.login_button.click()
        common.skip_login_to_home_popups()

        assert home_page.title_.wait_visible()
        assert isinstance(home_page.title_._present_element, WebElementTuple)
        assert isinstance(home_page.title_._visible_element, WebElementTuple)

        bottom.more.text
        bottom.more.visible_text
        bottom.more.click()
        assert home_page.title_.wait_invisible(1, present=False)
        assert isinstance(bottom.more._present_element, WebElementTuple)
        assert isinstance(bottom.more._visible_element, WebElementTuple)
        assert isinstance(bottom.more._clickable_element, WebElementTuple)
        start = time.time()
        # assert home_page.title_.wait_invisible(present=False) is True
        # assert home_page.title_.wait_absent() is True
        
        end = time.time()
        logstack.info(f'execute time: {end-start}s')
        # assert bottom.more.wait_unclickable(5, True, True)
        # assert not bottom.more.wait_unclickable(5, True, False)
        # assert not bottom.more.wait_unclickable(5, False, False)
        
        assert more_page.version_info.wait_invisible().text
        more_page.version_info.swipe_by()
        assert more_page.version_info.wait_visible().text

    @pytest.mark.app
    def test02(self, iphone, prelogin, common: Common):

        login_page = LoginPage(iphone)

        login_page.userid_input.present_element
        logstack.info('🕛 開始驗證效能')

        s = time.time()
        login_page.userid_input.wait_visible()
        # login_page.login_button.click()
        # login_page.userid_input.send_keys('X134624817')
        # login_page.username_input.send_keys('xxxx1234')
        # login_page.userpsw_input.send_keys('1111')
        e = time.time()
        logstack.info(e-s)

    @pytest.mark.app
    def test03(self, iphone, prelogin, common: Common):

        login_page = LoginPage(iphone)

        login_page.userid_input.present_element
        logstack.info('🕛 開始驗證效能')
        
        s = time.time()
        login_page.userid_input._wait_visible()
        # login_page.login_button.click()
        # login_page.userid_input.send_keys('X134624817')
        # login_page.username_input.send_keys('xxxx1234')
        # login_page.userpsw_input.send_keys('1111')
        e = time.time()
        logstack.info(e-s)
        