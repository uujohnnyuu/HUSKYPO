import time

import pytest
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.keys import Keys

from huskypo import logstack, Timeout

from trying.page.web_page import *
from trying.page.select_page import SelectPage


class TestWebPage:

    @pytest.mark.web
    def test_select_function(self, driver: WebDriver):

        testcase = 'test_my_page/google'

        my_page = SelectPage(driver)

        my_page.get("file:///Users/twipc00595080/Development/huskyPO/trying/select.html")

        my_page.fruit_list.options
        time.sleep(1)
        my_page.fruit_list.select_by_index(1)
        time.sleep(1)
        my_page.fruit_list.deselect_all()
        time.sleep(1)
        my_page.fruit_list.select_by_index(0)
        time.sleep(1)
        my_page.submit.click()
        time.sleep(1)

    @pytest.mark.web
    def test_action_key_down_and_up(self, driver: WebDriver):

        testcase = 'test_my_page/google'

        my_page = SelectPage(driver)

        my_page.get("file:///Users/twipc00595080/Development/huskyPO/trying/select.html")

        # my_page.fruit_list.key_down(Keys.COMMAND).send_keys_to_element('a').key_up(Keys.COMMAND).perform()
        # my_page.fruit_list.key_down(Keys.COMMAND).action_send_keys('a').key_up(Keys.COMMAND).perform()
        my_page.fruit_list.hotkey(Keys.COMMAND, 'a').action_click().perform()
        time.sleep(3)
        my_page.fruit_list.key_down(Keys.COMMAND).action_send_keys('a').key_up(Keys.COMMAND).perform()
        time.sleep(3)

    @pytest.mark.web
    def test_iframe_enabled(self, driver: WebDriver):

        testcase = 'test_my_page/google'

        my_page = IframePage(driver)
        my_page.get('https://www.surveycake.com/')

        result = my_page.iframe1.is_enabled()
        logstack.info(f'iframe enabled: {result}')

    @pytest.mark.web
    def test_actions(self, driver: WebDriver):

        testcase = 'test_my_page/google'

        my_page = ActionPage(driver)
        my_page.get('https://news.google.com/home?hl=zh-TW&gl=TW&ceid=TW:zh-Hant')

        logstack.info(f'location: {my_page.third.location}')
        logstack.info(f'size:     {my_page.third.size}')
        logstack.info(f'rect:     {my_page.third.rect}')

        my_page.third.scroll_to_element().drag_and_drop(my_page.second).action_click().perform()
        time.sleep(3)


    @pytest.mark.web
    def test_send_keys_functions(self, driver: WebDriver):

        testcase = 'test_my_page/google2'

        my_page = WebPage(driver)

        my_page.get("https://google.com")
        my_page.save_screenshot(testcase, "google_home_page")

        keyword = '忠孝復興熱炒'

        my_page.search_field.click()
        time.sleep(1)
        my_page.search_field.send_keys(keyword)
        time.sleep(1)
        my_page.search_field.clear()
        time.sleep(1)
        my_page.search_field.send_keys(keyword)
        time.sleep(1)
        my_page.search_field.submit()
        # my_page.search_field.input(keyword).backspace().input('123').backspace().tab().space().input('456').enter()

        my_page.save_screenshot(testcase, "google_home_page", 3)

        # Timeout.RERAISE = False

        # keyword = '哈哈哈哈哈哈哈哈....'

        # assert my_page.keyword_results(keyword).wait_all_not_present()
        # assert my_page.keyword_results(keyword).wait_all_not_visible(present=False)
        # assert my_page.keyword_results(keyword).wait_any_not_visible(present=False)

    @pytest.mark.web
    def test_keys_functions(self, driver: WebDriver):

        testcase = 'test_my_page/google2'

        my_page = WebPage(driver)

        my_page.get("https://google.com")
        my_page.save_screenshot(testcase, "google_home_page")

        keyword = '忠孝復興熱炒'

        my_page.search_field.input(keyword)
        time.sleep(1)
        my_page.search_field.backspace(2)
        time.sleep(1)
        my_page.search_field.input('123')
        time.sleep(1)
        my_page.search_field.backspace(3)
        time.sleep(1)
        my_page.search_field.space(4)
        time.sleep(1)
        my_page.search_field.input('456')
        time.sleep(1)
        my_page.search_field.arrow_left(7)
        time.sleep(1)
        my_page.search_field.delete(4)
        time.sleep(1)
        
        # my_page.search_field.enter()
